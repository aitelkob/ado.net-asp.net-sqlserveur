--Stored Procuders

--Select Books
CREATE PROC SelectBooks
as
SELECT * FROM Books_Table

--Insert Book

CREATE PROC InsertBook
@ID VARCHAR(50), @Title VARCHAR(75), @Author VARCHAR(50),
@Pages_Number INT, @Publish_Date DATETIME
AS
INSERT INTO Books_Table(ID, Title, Author, Publish_Date, Pages_Number)
VALUES (@ID, @Title, @Author, @Publish_Date, @Pages_Number)

--Delete Book

CREATE PROC DeleteBook
@ID VARCHAR(50)
AS
DELETE FROM Books_Table
WHERE ID=@ID

--Update Book

CREATE PROC UpdateBook
@ID VARCHAR(50), @Title VARCHAR(75), @Author VARCHAR(50),
@Pages_Number INT, @Publish_Date DATETIME
AS
UPDATE Books_Table
SET Title=@Title,
	Author=@Author,
	Pages_Number=@Pages_Number,
	Publish_Date=@Publish_Date
WHERE ID=@ID