create database societe_informatique
go
use societe_informatique
go

create table Type_App (
	num_type int primary key,
	nom_type varchar(50),
	nb_appareils int default 0,
	motdepasse varchar(50)
)

create table Societe (
	num_societe int primary key,
	num_registrecommerce int,
	nom_societe varchar(50),
	adresse varchar(50),
	telephone_societe varchar(50)
)

create table Client (
	num_client int primary key,
	nom varchar(50),
	prenom varchar(50),
	email varchar(50),
	adresse varchar(50),
	telephone varchar(50),
	nb_contrats int default 0,
	num_societe int references Societe (num_societe)
)

create table Appareil (
	num_appareil int primary key,
	nom_appareil varchar(50),
	date_achat date,
	prix_achat money,
	nb_contrats int default 0,
	num_type int references Type_App(num_type)
)

create table Contrat (
	num_police int primary key,
	date_contrat date,
	date_fin_contrat date,
	montant_contrat money,
	num_client int references Client(num_client),
	num_appareil int references Appareil(num_appareil),
	nb_rubriques int default 0
)

create table Rubrique (
	num_rubrique int primary key,
	nom_rubrique varchar(50),
	prix_rubrique money,
	num_contrat int references Contrat(num_police)
)

insert into Type_App
values (1, 'imprimate', 0, '123'),
	   (2, 'scanner', 0, '123'),
	   (3, 'pc', 0, '123')

insert into Appareil
values (1, 'canon 2018', GETDATE(), 1000, 0, 1),
	   (2, 'canon 11', GETDATE(), 500, 0, 2),
	   (3, 'Macbook pro', GETDATE(), 9000, 0, 3)

insert into Societe
values (1, 1, 'Info pro', 'Casablanca', '0522232425'),
	   (2, 2, 'Pc gamer', 'Rabat', '0522228899'),
	   (3, 3, 'InfoNet', 'Casablanca', '0522778833')

insert into Client
values (1, 'FAKHAM', 'Mohammed', 'mohammed.fakham@gmail.com', 'Casablanca', '0604040404', 0, 2),
	   (2, 'KARIM', 'Jawad', 'jawad.karim@gmail.com', 'Rabat', '0633221133', 0, 2),
	   (3, 'FATMI', 'Kamal', 'kamal.fatmi@gmail.com', 'Rabat', '0709221122', 0, 1)

insert into Contrat 
values (1, GETDATE(), DATEADD(month, 1, getdate()), 900, 1, 3, 0),
	   (2, GETDATE(), DATEADD(month, 1, getdate()), 200, 1, 1, 0),
	   (3, GETDATE(), DATEADD(month, 1, getdate()), 300, 2, 2, 0)

insert into Rubrique
values (1, 'Rubrique 1', 100, 1),
	   (2, 'Rubrique 2', 200, 2),
	   (3, 'Rubrique 3', 300, 3)

-- 2)
alter table Type_App
alter column nom_type varchar(50) not null

update Type_App
set nom_type = 'informatique'

alter table Type_App
add check(nom_type in('informatique', 'r�seau', '�quipement', 'autre'))

-- 3)
