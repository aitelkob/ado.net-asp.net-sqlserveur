create database ExerciceCurseur_BD;

use ExerciceCurseur_BD;

create table Avion(
	num int identity(1,1) primary key,
	marque varchar(20),
	typeA varchar(20)
)

insert into Avion
values('Airbus', 'A'),
	  ('Airbus','Civile'),
	  ('Boeing', 'Civile'),
	  ('F5', 'Militaire'),
	  ('TEST', 'T')

declare cursor_marque cursor
for select distinct marque from Avion

declare @marque varchar(20)
declare @type varchar(20)

open cursor_marque

fetch next from cursor_marque into @marque

while(@@FETCH_STATUS = 0)
begin
	declare cursor_type cursor
	for select typeA from Avion where marque = @marque

	open cursor_type

	fetch next from cursor_type into @type

	print 'Marque : ' + @marque
	print 'Type : '

	while(@@FETCH_STATUS = 0)
	begin
		print '  -' + @type

		fetch next from cursor_type into @type
	end

	close cursor_type
	deallocate cursor_type

	fetch next from cursor_marque into @marque
end

close cursor_marque
deallocate cursor_marque