create database SolidariteCo

use SolidariteCo
-- 1)
create table Type (
	idType int primary key,
	nomType varchar(50)
)

create table Responsable (
	idResp int primary key,
	nomResp varchar(20),
	prenomResp varchar(20),
	emailResp varchar(50),
	passResp varchar(20)
)

create table Action (
	idAct int primary key,
	nomAct varchar(30),
	description varchar(50),
	dateCreation date,
	dateFin date,
	montantAct money,
	nomBeneficaire varchar(20),
	prenBeneficaire varchar(20),
	dateDerniereDon date,
	idType int references Type(idType),
	idResp int references Responsable(idResp)
)

create table Donateur (
	idD int primary key,
	nomD varchar(20),
	prenomD varchar(20),
	emailD varchar(50),
	passD varchar(20)
)

create table Don (
	idDon int primary key identity,
	dateDon date,
	montantDon money,
	idAct int references Action(idAct),
	idD int references Donateur(idD)
)

set dateformat dmy;

go

insert into Type
values (1, 'Maladie'),
	   (2, 'Crise financi�re')

insert into Responsable
values (1, 'FAKHAM', 'Mohammed', 'mohammed.fakham@gmail.com', 'simosimo')

insert into Action
values (1, 'Action 1', 'Action 1', GETDATE(), '05/03/2018', 200, 'Beneficiare 1', 'Beneficiare 1', '01/01/2018', 1, 1)

insert into Donateur
values (1, 'KARAMI', 'Rida', 'karami.rida@gmail.com', 'ridarida')

insert into Don
values (GETDATE(), 200, 1, 1)

go

-- 2)

select A.nomAct, COUNT(distinct idD) as 'Nombre donateurs'
from Don D
inner join Action A on D.idAct = A.idAct
group by A.nomAct

-- 3)
go
create proc PS_ListeDons
	@idAct int
as
begin
	select D.montantDon, Dt.nomD
	from Don D
	inner join Donateur Dt on D.idD = Dt.idD
	where year(D.dateDon) = year(getdate()) and D.idAct = @idAct
end

-- 4)
go
create trigger MAJ_dateDerniereDon
on Don
for insert
as
begin
	declare @idAct int, @dateDon date

	select @idAct = idAct, @dateDon = dateDon from inserted

	update Action
	set dateDerniereDon = @dateDon
	where idAct = @idAct
end

-- 5)
go
create proc PS_AjouterDon
	@montantDon money, 
	@idAct int,
	@idD int
as
begin
	insert into Don
	values (getdate(), @montantDon, @idAct, @idD)
end

-- 6)
go
create function FCT_TotalDons(@idType int)
returns money
as 
begin
	declare @total money

	select @total = SUM(montantDon)
	from Don D
	inner join Action A on D.idAct = A.idAct
	inner join Type T on A.idType = T.idType

	return @total
end