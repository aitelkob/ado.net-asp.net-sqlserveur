use master
create database Gestion_stock
On Primary (
	name=Gestion_stock_data,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL10.SQLEXPRESS\MSSQL\DATA\Gestion_stock.mdf',
	size=5MB,
	maxsize=1GB,
	filegrowth=10%
)
Log On (
	name=Gestion_stock_log,
	filename='C:\Program Files\Microsoft SQL Server\MSSQL10.SQLEXPRESS\MSSQL\DATA\Gestion_stock.ldf',
	size=1MB,
	maxsize=512GB,
	filegrowth=10%
)
Go
use Gestion_stock
create table Magasin (
	NumM int IDENTITY(1,1) PRIMARY KEY,
	nomM varchar(20),
	adresse varchar(50),
	villeM varchar(20)
)
create table Produit (
	codeP int PRIMARY KEY,
	descriptionP varchar(20),
	prix money,
	couleur varchar(20) NOT NULL DEFAULT 'aucune couleur',
)
create table Stock (
	magasin int REFERENCES Magasin(NumM),
	Produit int REFERENCES Produit(codeP),
	qtte_stock int CHECK(qtte_stock between 1 and 100),
	PRIMARY KEY(magasin, Produit)
)
create table Client (
	codeCl int PRIMARY KEY,
	nomCl varchar(20),
	villeCl varchar(20)
)
create table Achat (
	NumA int PRIMARY KEY,
	dateAchat datetime,
	Client int REFERENCES Client(codeCl),
	magasin int REFERENCES Magasin(NumM)
)
create table Detail (
	Achat int REFERENCES Achat(NumA),
	Produit int REFERENCES Produit(codeP),
	qtte int,
	PRIMARY KEY(Achat, Produit)
)
Go
alter table Client
add constraint chk_client_nomCl check(len(nomCl) >= 4)
Go
alter table Achat
add constraint chk_achat_dateAchat check(DateDiff(second, getdate(), dateAchat) >= 0)
Go
alter table Produit
add remise float
Go
alter table Produit
add Prix_remise AS prix - (prix/100 * remise)
Go
DECLARE @ObjectName NVARCHAR(100)
select @ObjectName =  name from sys.objects where name like 'CK__Stock__%';

exec('alter table Stock drop constraint ' + @ObjectName)
Go
INSERT INTO Magasin(nomM, adresse, villeM)
VALUES('Magasin 1', 'Sidi Moumen', 'CASA')
INSERT INTO Produit
VALUES(1, 'PC', 5000, 'rouge', 2)
INSERT INTO Stock
VALUES(1, 1, 5)
INSERT INTO Client
VALUES(1, 'Mohammed', 'CASA')
INSERT INTO Achat
VALUES(1, GETDATE(), 1, 1)
INSERT INTO Detail
VALUES(1, 1, 1)
Go
UPDATE Produit
SET prix = prix * 0.9
WHERE couleur = 'rouge'
--DELETE FROM Achat
--WHERE Client = (select NumA from Achat where DATEDIFF(day, dateAchat, getdate()) = 0)
--DELETE FROM Client
--WHERE codeCl = (select NumA from Achat where DATEDIFF(day, dateAchat, getdate()) = 0)
DECLARE @codeCl nvarchar(20)
select @codeCl = NumA from Achat where DATEDIFF(day, dateAchat, getdate()) = 0
DELETE FROM Achat
WHERE Client = @codeCl
DELETE FROM Client
WHERE codeCl = @codeCl
Go
SELECT NumM, NomM, convert(varchar,dateAchat, 103) AS 'Date', COUNT(*) AS 'Nombre de visiteurs'
FROM Magasin
INNER JOIN Achat ON magasin=NumM
WHERE nomM = 'BIM STORES ANOUAL'
GROUP BY NumM, nomM, convert(varchar,dateAchat, 103)
Go
SELECT NumA, dateAchat, SUM(prix * qtte) AS 'Total Normal', SUM(prix_remise * qtte) AS 'Total avec remise'
FROM Detail
INNER JOIN Achat ON Achat.NumA = Detail.Achat
INNER JOIN Produit ON Detail.Produit = Produit.codeP
GROUP BY NumA, dateAchat