create database Exercice10_BD;

use Exercice10_BD;

create table Ordinateur(
	num_serie int primary key,
	marque varchar(15),
	modele varchar(15),
	date_acquisition date
)

set dateformat dmy;

insert into Ordinateur
values(1, 'HP', '2010', '01/01/2010'),
	  (2, 'Tochiba', '2011', '01/01/2011'),
	  (3, 'Sony', '2011', '02/02/2011'),
	  (4, 'Compaq', '2011', '03/03/2011'),
	  (5, 'Dell', '2012', '01/01/2012'),
	  (6, 'Mac Book', '2012', '02/01/2012')
	  
go
create function nb_ordinateurs_ann�e(@annee int)
returns @t table( annee varchar(4),
				  nombreOrdinateurs int)
as
begin
	declare @nb int = 0
	declare @finAnnee int
	
	select @finAnnee = cast(max(year(date_acquisition)) as int)
	from Ordinateur
	
	while(@annee <= @finAnnee)
	begin
		select @nb = count(*)
		from Ordinateur
		where year(date_acquisition) <= @annee
		
		insert into @t
		values(@annee, @nb)
		
		set @annee = @annee + 1
	end
	
	return
end
go

select *
from dbo.nb_ordinateurs_annee(2009)