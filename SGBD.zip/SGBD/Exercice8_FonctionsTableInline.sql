create database Exercice8_BD;

use Exercice8_BD;

create table Utilisateur(
	Id int primary key,
	Pseudo varchar(20),
	Email varchar(30),
	MotDePasse varchar(20),
	DateInscription date
)

create table Salle(
	Id int primary key,
	Theme varchar(20)
)

create table Message(
	IdUtilisateur int references Utilisateur(Id),
	IdSalle int references Salle(Id),
	dateEnvoi date,
	corps varchar(50)
)
-- 2)
go
create function ListeUtilisateurs()
returns table
as
	return select IdUtilisateur
		   from Message
go
-- 3)
go
create function ListeUtilisateursParSalle(@salle int)
returns table
as
	return select IdUtilisateur
		   from Message
		   where IdSalle = @salle
go
-- 4)
go
create function Participants(@salle int)
returns table
as
	return select top 3 IdUtilisateur
		   from Message
		   group by IdUtilisateur
		   order by count(*) desc
go
-- 5)
