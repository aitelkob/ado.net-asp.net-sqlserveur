create database Vente;

use Vente;

create table Client(
	CodeCl int primary key,
	Nom varchar(30),
	Ville varchar(20)
)

create table Article(
	CodeArt int primary key,
	Designation varchar(20),
	PU money,
	QStock int
)

create table Commande (
	NumCom int primary key,
	DateCom date,
	CodeCl int references Client(CodeCl)
)

create table Detail (
	NumCom int references Commande(NumCom),
	CodeArt int references Article(CodeArt),
	Qte int,
	primary key (NumCom, CodeArt)
)

insert into Client
values(1, 'Alami', 'Casa'),
	  (2, 'Fikri', 'Rabat'),
	  (3, 'Naji', 'Safi'),
	  (4, 'Nassiri', 'Jdida'),
	  (5, 'Kadiri', 'Oujda'),
	  (6, 'Sabri', 'Tetouan'),
	  (7, 'Essafi', 'Tanja')