create database Exercice13_BD;

use Exercice13_BD;

create table Adherent(
	Num_Adh int identity(1,1) primary key,
	Nom_Adh varchar(20),
	Prenom_Adh varchar(20),
	Date_Naissance date
)

create table Livre(
	Num_Li int identity(1,1) primary key,
	Titre varchar(50),
	Duree_Max_Emprunt int,
	Emprunte int
)

create table Emprunt(
	Num_Emp int identity(1, 1) primary key,
	Num_Adh int references Adherent(Num_Adh),
	Num_Li int references Livre(Num_Li),
	Date_Emprunt date,
	Date_Retour date
)

create table Archive(
	Nom_Prenom_Adh varchar(40),
	Titre_livre varchar(50),
	Date_Emprunt date,
	Date_Retour date
)

--1)
go
create proc sp_AjoutLivre(@titre varchar(50), @duree int)
as
begin
	insert into Livre
	values(@titre, @duree, 0)
end
go
--2)
exec sp_AjoutLivre 'Livre 1', 20
exec sp_AjoutLivre 'Livre 2', 30
exec sp_AjoutLivre 'Livre 3', 25
--3)
go
create proc sp_LivresEmpruntes
as
begin
	select L.*
	from Emprunt E
	inner join Livre L
	on E.Num_Li = L.Num_Li
end
go
--4)
go
create proc sp_AjouterAdherent(@num int OUTPUT, @nom varchar(20), @prenom varchar(20), @dateNaissance date)
as
begin
	insert into Adherent
	values(@nom, @prenom, @dateNaissance)
	select @num = @@IDENTITY
end
go
--5)
go
create proc sp_Emprunter(@num_adh int, @num_li int, @dateRetour date)
as
begin
	IF NOT EXISTS(select * from Livre where Num_Li = @num_li)
		return 1
	ELSE IF NOT EXISTS(select * from Adherent where Num_Adh = @num_adh)
		return 2
	ELSE IF EXISTS(select * from Emprunt where Num_Li = @num_li)
		return 3
	ELSE
	begin
		declare @nbr int
		select @nbr = count(*) from Emprunt where Num_Adh = @num_adh

		IF(@nbr >= 3)
			return 4
		ELSE
		begin
			insert into Emprunt
			values(@num_adh, @num_li, GETDATE(), @dateRetour)
			
			return 0
		end
	end
end
go
--6)
declare @num int
declare @err int
exec sp_AjouterAdherent @num OUTPUT, 'FAKHAM', 'Mohammed', '01/03/1997'
exec @err = sp_Emprunter @num, 1, '15/03/2018'

IF (@err = 1)
	print 'Le livre n�existe pas'
ELSE IF (@err = 2)
	print 'l�adh�rent n�existe pas'
ELSE IF (@err = 3)
	print 'le livre est d�j� emprunt�'
ELSE IF (@err = 4)
	print 'l�adh�rent emprunte d�j� 3 livres'
--7)
go
create proc sp_SuppAdh�rent(@num int)
as
begin
	IF EXISTS(select * from Emprunt where Num_Adh=@num and Date_Retour > GETDATE())
		raiserror('l�adh�rent n�a pas retourn� des livres', 16, 1)
	ELSE
	begin
		begin try
			begin tran
				insert into Archive
				select Nom_Adh + ' ' + Prenom_Adh, Titre, Date_Emprunt, Date_Retour
				from Emprunt E
				inner join Adherent A on A.Num_Adh = E.Num_Adh
				inner join Livre L on L.Num_Li = E.Num_Li
				where E.Num_Adh = @num

				delete from Emprunt
				where Num_Adh = @num

				delete from Adherent
				where Num_Adh = @num
			commit tran
		end try
		begin catch
			rollback tran
		end catch
	end
end
go
--8)
exec sp_SuppAdh�rent 9
--9)
go
create proc sp_RetournerLivre(@num_livre int, @nbrJours int OUTPUT)
as
begin
	IF NOT EXISTS(select * from Livre where Num_Li = @num_livre)
		raiserror('le livre n�existe pas', 16, 1)
	ELSE IF NOT EXISTS(select * from Emprunt where Num_Li = @num_livre)
		raiserror('le livre n�est pas emprunt�', 16, 1)
	ELSE
	begin
		select @nbrJours = DATEDIFF(day, Date_Retour, getdate())
		from Emprunt
		where Num_Li = @num_livre

		update Emprunt
		set Date_Retour = GETDATE()
		where Num_Li = @num_livre
	end
end
go
--10)
exec sp_RetournerLivre 1, null
--11)
exec sp_SuppAdh�rent 9