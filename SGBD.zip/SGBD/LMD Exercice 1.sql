use master
create database Ecole

use Ecole
create table Etudiant(
	NEtudiant int primary key,
	Nom varchar(10),
	Pr�nom varchar(10)
)

create table Matiere(
	CodeMat int primary key,
	libell�Mat varchar(20),
	CoeffMat int
)

create table Evaluer(
	NEtudiant int references Etudiant(NEtudiant),
	CodeMat int references Matiere(CodeMat),
	DateE date,
	Note float,
	primary key(NEtudiant, CodeMat)
)

alter table Etudiant
add DateN date

alter table Etudiant
add Groupe varchar(10) not null

alter table Etudiant
add Age AS datediff(year, DateN, getdate())

alter table Evaluer
add constraint CK_Evaluer_Note check(Note between 0 and 20)

set dateformat dmy
insert into Etudiant
values(1, 'FAKHAM', 'Mohammed', '01/03/1997', 'TDI201'),
      (2, 'AMRANI', 'Ali', '19/08/2009', 'TRI101');
      
insert into Matiere
values(1, 'POO', 5),
      (2, 'SGBDI', 6),
      (3, 'Langage C', 3),
      (4, 'Math', 7);
      
insert into Evaluer
values(1, 1, GETDATE(), 17),
      (2, 1, GETDATE(), 3),
      (2, 4, GETDATE(), 2);
      
update Evaluer
set Note = Note + 3

update Evaluer
set Note = Note + 2
where Note < 10

update E
set Note = Note + 3
from Evaluer E
inner join Matiere M
on M.CodeMat = E.CodeMat
where E.Note < 10 and M.libell�Mat = 'Math'

delete E
from Etudiant E
where NEtudiant not in (select NEtudiant
						from Evaluer)
						
select Et.Groupe, Et.Nom, Et.Pr�nom, SUM(Note * CoeffMat) / SUM(CoeffMat) AS 'Moyenne G�n�ral'
from Etudiant Et
inner join Evaluer Ev on Et.NEtudiant = Ev.NEtudiant
inner join Matiere M on M.CodeMat = Ev.CodeMat
group by Et.Groupe, Et.Nom, Et.Pr�nom
