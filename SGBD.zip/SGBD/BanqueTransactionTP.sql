use master
create database Banque
use Banque

create table Personne (
	NumP int primary key,
	Nom varchar(20),
	Ville varchar(20)
)

create table Compte (
	NumC int primary key,
	NumP int references Personne(NumP),
	DateCreation date,
	solde money
)

create table Mouvement (
	NumM int primary key identity(1,1),
	Montant money,
	C_C int references Compte(NumC),
	C_D int references Compte(NumC),
	DateM date
)

insert into Personne
values (1, 'ALAMI', 'CASA'),
	   (2, 'EL MARJANI', 'RABAT'),
	   (3, 'MARJANE', 'CASA');
	   
insert into Compte
values (123456, 1, '30/11/2017', 20000),
       (654321, 2, '27/11/2017', 25000),
       (1111, 3, '10/10/2010', 99999);
       
begin try
	begin tran
		update Compte
		set solde = solde - 5000
		where NumC = 123456;
		
		update Compte
		set solde = solde + 5000
		where NumC = 654321;
		
		insert into Mouvement(Montant, C_C, C_D, DateM)
		values (5000, 654321, 123456, getdate());
	commit tran
end try
begin catch
	rollback tran
end catch

begin tran
	update Compte
	set solde = solde - 2000
	where NumC = 123456;
	
	update Compte
	set solde = solde + 2000
	where NumC = 1111;
	
	insert into Mouvement(Montant, C_C, C_D, DateM)
	values (2000, 1111, 123456, GETDATE());
	
IF @@TRANCOUNT < 3
	ROLLBACK TRAN
ELSE
	COMMIT TRAN
	
truncate table Mouvement;

delete Compte
from Compte C
inner join Personne P on P.NumP = C.NumP
where Nom = 'ALAMI';
	
select * from Mouvement