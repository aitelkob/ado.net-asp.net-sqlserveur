create  database Vente 
use Vente

create table Client (CodeCi int primary key ,
                      Nom varchar(30),
					  Ville varchar(30))

create table Article (CodeArt int primary key ,
                       Designation varchar(30),
					   Pu float,
					   QStock int )

create table Commande(NumCom int primary key ,
                       dateCom date ,
					   CodeCi int references Client(CodeCi) )

drop table D�tail
create table D�tail (NumCom int references Commande(NumCom) ,
                    CodeArt int references Article(CodeArt),
					Qte int
					primary key (NumCom,CodeArt) )
                      

				

					  

insert into Client values(10,'youssef','CASABLANCA'),
                         (11,'youssef','fes'),
						 (12,'youssef','rabat'),
						 (13,'anas','asfi')
						 select * from Client
insert into Article values(300,'stylo',50,15),
                          (400,'stylo',50,17),
						  (500,'bord',90,16),
						  (600,'stylo',50,15),
						  (700,'cover',5,14)

select *from client where nom like 'a%'

					select * from Article
insert into Commande values(1,'02/03/2017',10),
                          (2,'02/03/2017',11),
							(3,'03/03/2017',12),
							(4,'04/03/2017',13),
							(5,'05/03/2017',11),
							(6,'06/03/2017',10),
							(7,'06/03/2017',13),
							(8,'07/03/2017',13)		
		
						delete D�tail
insert into D�tail values (1,300,5),
                          (2,500,15),
						  (3,600,8),
						  (4,700,50),
						  (5,400,9),
						  (6,300,10),
						  (7,700,20)
						  
						  select * from D�tail


select cl.CodeCi,cl.Nom,count(c.NumCom)as'nbr_command' ,sum(Pu*Qte)as'Prixtt'
from Commande c 
inner join D�tail d 
on c.NumCom=d.NumCom
inner join Client cl
on c.CodeCi=cl.CodeCi
inner join Article a
on a.CodeArt=d.CodeArt
group by cl.CodeCi,cl.Nom


 select * from Article  
 
 select * from Client 	
 
 select * from Commande	
 
 select * from D�tail		
 
 
select cl.CodeCi,cl.Nom,cl.Ville,count(c.NumCom)as nOmbrecommande
from Commande c 
inner join Client cl
on c.CodeCi=cl.CodeCi
group by cl.CodeCi,cl.Nom,cl.Ville




select *,
from  Client cl
inner join Commande c
on c.CodeCi=cl.CodeCi



delete
from
				