create database CabinetMedical
use CabinetMedical

create table Heure_RDV(
	Heure time primary key
)

create table RDV(
	NUM_RDV int primary key,
	DATE_RDV date,
	HEURE_RDV time references Heure_RDV(Heure),
	PATIENT int
)

declare @HeureDebut time = '8:00'
declare @HeureFin time = '14:00'
declare @duree int = 20

delete Heure_RDV

declare @heure time = @HeureDebut
declare @n int = @duree

while(@heure < @HeureFin)
begin
	insert into Heure_RDV
	values(@heure);
	set @heure = DATEADD(minute, @n, @heure)
end

select * from Heure_RDV

declare @jour date = getdate();
declare @trouvee bit = 0

while(@trouvee = 0)
begin
	if not exists((select Heure from Heure_RDV except select Heure_RDV from RDV where DATE_RDV = @jour))
		set @jour = DATEADD(day, 1, @jour);
	else if (DATEPART(weekday, @jour) between 6 and 7)
		set @jour = DATEADD(day, 1, @jour);
	else
	begin
		select top 1 Heure
		from Heure_RDV
		except
		select Heure_RDV
		from RDV
		where DATE_RDV = @jour;
		set @trouvee = 1;
	end
end

insert into RDV
values(1, GETDATE(), '8:00', 1)