create database Triggers_BD

use Triggers_BD

create table Client(
	numClient int primary key,
	nom varchar(20),
	points int
)

create table Commande(
	numCommande int primary key,
	dateCommande date,
	numClient int references Client(numClient)
)

create table Produit(
	numProduit int primary key,
	libelle varchar(30),
	prix money,
	dateExpiration date,
	qtte_stock int
)

create table Commande_Produit(
	numCommande int references Commande(numCommande),
	numProduit int references Produit(numProduit),
	qtteCommande int,
	primary key (numCommande, numProduit)
)

go
-- 1)
create trigger TR_Qtte_Stock
on Commande_Produit
for insert, delete
as
begin
	declare @qtteC int, @numP int, @qtteS int
	select @numP = numProduit, @qtteC = qtteCommande from inserted

	select @qtteS = qtte_Stock from Produit where numProduit=@numP

	if (@qtteS < @qtteC)
		rollback
	else
	begin
		if exists(select * from inserted)
			update Produit set qtte_stock = qtte_stock - @qtteC where numProduit=@numP
		else
			update Produit set qtte_stock = qtte_stock + @qtteC where numProduit=@numP 
	end
end
--2)
go
create trigger TR_Limite_Produits
on Commande_Produit
for insert
as
begin
	declare @nbrProduits int

	select @nbrProduits = count(*) 
	from inserted I 
	inner join Commande_Produit CP
	on I.numCommande = CP.numCommande

	if (@nbrProduits > 10)
		rollback
end
-- 3)
go
create trigger TR_ReduirePrix
on Produit
for insert, update
as
begin
	declare @qtteS int, @numP int
	select @qtteS = qtte_stock, @numP=numProduit from inserted

	if (@qtteS < 500)
		update Produit
		set prix = prix * 0.9
		where numProduit = @numP
end
--4)
go
create trigger TR_ModificationCommande
on Commande
for update
as
begin
	if exists(select * from inserted where DATEDIFF(month, dateCommande, getdate()) <> 0)
		rollback 
end
--5)
go
alter table Commande
add nbr_produits int default 0

alter table Client
add nbr_commande int default 0
--6)
go
create trigger TR_MAJ_Commande
on Commande_Produit
for insert, delete
as
begin
	declare @nbr_produits int, @numC int

	select @numC = numCommande from inserted

	select @nbr_produits = COUNT(*)
	from inserted I
	inner join Commande_Produit CP
	on I.numCommande = CP.numCommande

	update Commande
	set nbr_produits = @nbr_produits
	where numCommande=@numC
end
--7)
go
create trigger TR_MAJ_Client
on Commande
for insert, delete
as
begin
	declare @nbr_commande int, @numC int

	select @numC=numClient from inserted 

	select @nbr_commande = COUNT(*)
	from inserted I
	inner join Commande C
	on I.numCommande = C.numCommande
	where C.numClient=@numC

	update Client
	set nbr_commande=@nbr_commande
	where numClient=@numC
end