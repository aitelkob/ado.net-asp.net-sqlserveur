create database Gestion_Produit




create table Client
(
	Num_Client int primary key,
	Nom varchar(20),
	Points int
)
create table Commande
(
	Num_Commande int primary key,
	Date_Commande date,
	Num_Client int references Client(Num_Client)
)
create table Produit
(
	Num_Produit int primary key,
	Libelle varchar(20),
	Prix money,
	Date_Expiration date,
	Qtte_Stock int
)
create table Commande_Produit
(
	Num_Commande int references Commande(Num_Commande),
	Num_Produit int references Produit(Num_Produit),
	Qtte_Commande int,
	primary key(Num_Commande,Num_Produit)
)

insert into Client values(1,'Alami',15),(2,'Karimi',14)
insert into Commande values(1,'12/02/2017',2),(2,'02/02/2018',1)
insert into Produit values(1,'A10',150,'02/01/2020',30),(2,'A20',20,'03/04/2025',10)
insert into Commande_Produit values(1,1,50),(2,1,30)


select * from Client
select * from Commande
select * from Produit
select * from Commande_Produit