create database Gestion_projet

create table Emp 
(
	num_emp int primary key,
	nom varchar(10),
	prenom varchar(20)
)
create table Projet 
(
	numP int primary key ,
	description varchar (10),
	prix_heure money,
	nbre_heures int ,
	chef int references Emp(num_emp)
)
create table Travail 
(
	numP int references projet (numP),
	numEmp int references Emp (num_emp),
	dateT date,
	nbre_heures int,
	primary key (numP,numEmp,dateT)
)

insert into Emp
values(1,'andaloussi','manel'),(2,'fakham','mohamed')

insert into Projet
values(10,'Bimwor',500,14,1),(12,'conSpiker',1000,20,2)

insert into Travail 
values(10,1,'12/03/2017',14),(12,2,'02/01/2018',20)

go
create function Nbr_employ� (@numP int)
returns int 
as
Begin 
	declare @nbre_employ� int
	select @nbre_employ�=count(*) from Travail where numP=@numP 
	-- set @nbre_employ� = (select count(*) from Travail where numP=@numP) 
	return @nbre_employ�
end
go

select dbo.Nbr_employ�(10)

go
create function InfoP(@numP int)
returns @t table (numP int , description varchar (20),Nb_employ�s int)
as 
begin 
	--declare @numP int =(select numP from Travail where numP=@numP)
	--declare @description =(select description from Travail where numP=@numP)
	--declare @Nb_employ�s int=(select dbo.Nbr_employ�(@numP))

	declare @Nb_employ�s int
	declare @description varchar(10)

	select @description=description, @Nb_employ�s=dbo.Nbr_employ�(@numP)
	from Projet
	where numP=@numP

	insert into @t
	values(@numP,@description,@Nb_employ�s)

	return

end
go
create proc PS_sLR_emp (@projet int,@salaire money Output,@dateD date,@dateF date,@Emp int)
as
begin 
	select @salaire =SUM(prix_heure*T.nbre_heures) from projet P INNER JOIN travail T ON P.numP=T.numP where P.numP= @projet AND dateT BETWEEN @dateD AND @dateF AND numEmp=@Emp 

end
go
set dateformat dmy
Declare @salaire int
exec PS_sLR_emp 10,@salaire output,'11/03/2017','14/03/2017',1
print @salaire
go
create proc ps_affiche_projet
as
begin
	
	declare cursor_projet cursor for (select nom,description, numP from Projet P INNER JOIN Emp E ON P.chef=E.num_emp) 
	Declare @nom varchar(20)
	declare @description varchar(20)
	declare @numP int
	open cursor_projet
	fetch next from cursor_projet into @nom,@description,@numP 
	while (@@FETCH_STATUS=0)
	begin 
		print 'projet : '+@description
		print 'chef : '+@nom
		print 'Employes : '
		declare cursor_emp cursor for(select distinct(nom) from Emp E INNER JOIN Travail T ON E.num_emp=T.numEmp where numP=@numP)
		open cursor_emp
		fetch next from cursor_emp into @nom
		while(@@FETCH_STATUS=0)
		begin
			print '    - '+@nom
			fetch next from cursor_emp into @nom
		end 
		close cursor_emp
		deallocate cursor_emp
		fetch next from cursor_projet into @nom, @description, @numP
	end
	close cursor_projet
	deallocate cursor_projet
end