create database Exercice7_BD;

use Exercice7_BD;

create table Departement(
	DeptNo int primary key,
	NomDept varchar(20)
)

create table Employe(
	Id int primary key,
	Nom varchar(15),
	Prenom varchar(15),
	Salaire money,
	DeptNo int references Departement(DeptNo)
)
-- 1)
go
create function fct_nombreEmployes(@DeptNo int)
returns int
as
begin
	declare @nbrEmp int
	select @nbrEmp = count(*)
	from Employe
	where DeptNo = @DeptNo
return @nbrEmp
end
go
-- 2)
select DeptNo
from Employe
where dbo.fct_nombreEmployes(DeptNo) > 5
-- 3)
go
create function fct_salaireMoyen(@DeptNo int)
returns money
as
begin
	declare @moyen money
	
	select @moyen = avg(Salaire)
	from Departement D
	inner join Employe E
	on D.DeptNo = E.Id
	having count(*) > 5
	
	return @moyen
end
go
-- 4)
select DeptNo, NomDept, dbo.fct_nombreEmployes(1) as 'Nombre employ�s', dbo.fct_salaireMoyen(1) as 'Salaire moyen'
from Departement
-- 5)
go
alter function fct_salaireMoyen(@DeptNo int)
returns money
as
begin
	declare @moyen money
	
	select @moyen = (max(Salaire) + min(Salaire)) / 2
	from Departement D
	inner join Employe E
	on D.DeptNo = E.Id
	having count(*) > 5
	
	return @moyen
end
go
select DeptNo, NomDept, dbo.fct_nombreEmployes(1) as 'Nombre employ�s', dbo.fct_salaireMoyen(1) as 'Salaire moyen'
from Departement
-- 6)
go
create function fct_majMin(@s varchar(100))
returns varchar(100)
as
begin
	declare @r varchar(100)
	set @r = upper(left(@s, 1)) + lower(right(@s, len(@s) - 1));
	
	return @r
end
go
-- 7)
select dbo.fct_majMin(Prenom) as 'Nouveau format'
from Employe