create database Exercice11_BD;

use Exercice11_BD;

set dateformat dmy;

go
alter proc sp_semaine
as
begin
	if OBJECT_ID('Semaine') IS NULL
	begin
		create table Semaine(jour date)
		
		declare @i date = dateadd(day, 1, getdate());
		
		while(@i <= DATEADD(day, 7, getdate()))
		begin
			insert into Semaine
			values(@i)
			
			set @i = DATEADD(day, 1, @i)
		end
	end
end
go

exec sp_semaine

select *
from semaine

drop proc sp_semaine