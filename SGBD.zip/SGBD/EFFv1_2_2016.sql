create database Solidarite_Co
use Solidarite_Co

--------- table type 
create table Type(
idtype int primary key,
nomeType varchar(25))

---insertion

insert into Type values(1,'type1'),
                       (2,'type2'),
					   (3,'type3'),
					   (4,'type4')



----------table Responsable

go 

create table Responsable(
idRespo int primary key,
nomResp varchar(25),
prenomResp DECIMAL,
emailResp varchar(25),
passResp varchar(25))
-----insertion
insert into Responsable values (10,'Nomrspo1',50,'abc1@gmail.com',123),
                                (20,'Nomrspo2',60,'abc2@gmail.com',456),
								(30,'Nomrspo3',70,'abc3@gmail.com',789),
								(40,'Nomrspo4',66,'abc4@gmail.com',852)

-----------------table Action
create table Action(
idAct int primary key ,
nomAct varchar(25),
description varchar(250),
dateCreation date,
dateFin date,
MontantAct  float,
nomBeneficiare varchar(25),
idType int references Type(idType),
idResp int references Responsable(idRespo)
)
-----insertion
insert into Action values(111,'nomAct1','description1','01/01/2016',GETDATE(),15,'nomb1',1,10),
                         (222,'nomAct2','description2','01/02/2016',GETDATE(),15,'nomb2',2,20),
						 (333,'nomAct3','description3','01/03/2016',GETDATE(),15,'nomb3',3,30),
						 (444,'nomAct4','description4','01/04/2016',GETDATE(),15,'nomb4',4,40)



---------------------table donateur

create table Donateur(
idD int primary key,
nomD varchar(25),
prenomD varchar(25),
emailD varchar(25),
passD varchar(25))
----insertion

insert into Donateur values (100,'nomD1','prenomD1','abcD@gmail.com','123'),
                            (200,'nomD2','prenomD2','abcD2@gmail.com','123'),
							(300,'nomD3','prenomD3','abcD3@gmail.com','123'),
							(400,'nomD4','prenomD4','abcD4@gmail.com','123')

------------------------table Don

create table Don(
idDon int primary key ,
dateDon date,
montantDon float,
idAct int references Action(idAct),
idD int references Donateur(idD))
 
 --------insertion 

 insert into Don values (111,getdate(),15,111,100),
                        (222,getdate(),15,222,200),
						(333,getdate(),15,333,300),
						(444,getdate(),15,444,400)



---------------test


select * from Responsable

select * from Donateur



select idRespo 
from Responsable
where idRespo=  and passResp=
union
select idD
from Donateur
where idD=  and passD=
where 