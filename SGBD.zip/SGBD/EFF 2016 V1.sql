create database Humain_co
use Humain_co
--table categorie 
create table categorie(
idCategorie int primary key,
nomCategorie varchar(50),
)
--insertion
insert into categorie
values (1,'categorie1'),
       (2,'categorie2')
	   go
--table organisateur
create table organisateur(
idOrg int primary key,
nomOrg varchar(40),
prenomOrg varchar(40),
emailOrg varchar(50),
passOrg varchar(50)
)

insert into organisateur
values (1,'alami','amir','alami@gmail.com','123'),
       (2,'salmi','salim','salmi@gmail.com','143')

go
--table campagne
create table campagne(
idCamp int primary key,
nomCamp varchar(50),
description varchar(50),
dateCreation date ,
dateFin date ,
montantCamp real,
nomBenificiaire varchar(50),
prenBenificiaire varchar(50),
dateDernierePart date ,
idCategorie int foreign key references  categorie  (idCategorie),
idOrg int foreign key references organisateur(idOrg)
)
insert into campagne
values (1,'campagne1','des1','3/03/2018','3/28/2018',14,'benificier1','prenom1','4/4/2018',1,1),
       (2,'campagne2','des2','4/03/2018','4/28/2018',12,'benificier2','prenom2','4/5/2018',2,2)
GO
--table Participant
create table participant(
idP int primary key,
nomP varchar(50),
prenomP varchar(50),
emailP varchar(50),
passP varchar(50)
)
go 
insert into participant
values (1,'participant1','part1','part1@gmail.com','123'),
       (2,'participant2','part2','part2@gmail.com','145')
go

--table participation
create table participation(
idPart int primary key identity,
datePartt date,
montantPart real ,
idCamp int foreign key references campagne (idCamp),
idP int foreign key references participant(idP)
)
insert into participation
values('3/5/2018',13,1,2),
      ('3/15/2018',15,1,2)


 select * from organisateur



 insert into organisateur
values (3,'alami','amir','alami@gmail.com','123')


delete organisateur where idOrg=


