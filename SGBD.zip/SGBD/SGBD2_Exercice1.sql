create database DB_zineb
create table Membre(
	pseudo varchar(20) PRIMARY KEY,
	E_mail varchar(20),
	mot_de_passe varchar(20),
	date_naissance date,
	date_inscription date,
	ville varchar(20)
)  

insert into Membre(pseudo,E_mail,mot_de_passe,date_naissance,date_inscription,ville)
values('zineb123','zineb.ELHASSNAOUI@GMAIL.com','zineb123','16/10/1997','10/10/2017','casa');

declare @ville varchar(20)
set @ville='casa'
select @ville 


declare @nbMembre varchar(20)
set @nbMembre=(select @nbMembre
			   from Membre)
 



