create database Exercice9_BD;

use Exercice9_BD;

create table Personne(
	nom varchar(30) primary key,
	adresse varchar(30),
	dateNaissance date
)

set dateformat dmy;

insert into Personne
values('Mohammed', 'casa', '01/03/1997'),
	  ('Badr', 'casa', '09/11/1995'),
	  ('Mona', 'rabat', '22/08/2000')
	  
go
create function nbPersonneTranche(@nb int)
returns @t table(minAge int,
				 maxAge int,
				 nombre int)
as
begin
	declare @age int = 0
	declare @nombre int = 0
	
	while(@age <= 29)
	begin
		select @nombre = count(*)
		from Personne
		where datediff(year, dateNaissance, getdate()) between @age and @age + @nb - 1
		
		insert into @t
		values(@age, @age + @nb - 1, @nombre)
		
		set @age = @age + @nb
	end
	
	return
end
go

select *
from dbo.nbPersonneTranche(10)