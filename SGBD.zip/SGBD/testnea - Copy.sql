select * from client

delete Client
set Nom,ville
where CodeCi

insert into client values (10009,'youssef','casa')


delete client 
set Nom='youssef',ville='{1}' where CodeCi={2} "