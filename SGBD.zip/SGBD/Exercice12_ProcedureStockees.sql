create database Exercice12_BD;

use Exercice12_BD;

create table Adherent(
	code int primary key,
	nom varchar(15),
	prenom varchar(15)
)

create table Activite(
	refActivite int primary key,
	intitule varchar(30),
	NbMaxParticipant int
)

create table Inscription(
	code int references Adherent(code),
	refActivite int references Activite(refActivite),
	dateI date,
	primary key(code, refActivite)
)
-- 2)
go
create proc sp_ajouter_adherent(@code int, @nom varchar(15), @prenom varchar(15))
as
begin
	insert into Adherent
	values(@code, @nom, @prenom)
end
go
-- 3)
exec sp_ajouter_adherent 1, 'FAKHAM', 'Mohammed'
-- 4)
go
create proc sp_ajouter_activite(@refActivite int, @intitule varchar(30), @NbMaxParticipant int)
as
begin
	insert into Activite
	values(@refActivite, @intitule, @NbMaxParticipant)
end
go
-- 5)
exec sp_ajouter_activite 1, 'Test', 20
-- 6)
go
create proc sp_ajouter_inscription(@code int, @refActivite int, @dateI date)
as
begin
	declare @nbMax int 
	declare @nbMaxActivite int

	select @nbMax = count(*) from Inscription where refActivite = @refActivite
	select @nbMaxActivite = NbMaxParticipant from Activite where refActivite = @refActivite

	if (@nbMaxActivite <= @nbMax)
	begin
		if (@dateI is null)
		begin
			insert into Inscription
			values(@code, @refActivite, GETDATE())
		end
		else
		begin
			insert into Inscription
			values(@code, @refActivite, @dateI)
		end
	end
end
go
-- 7)
exec sp_ajouter_inscription 1, 1, null
-- 8)
go
create proc sp_liste_activites
as
begin
	select A.refActivite, intitule, NbMaxParticipant, COUNT(*) AS 'Nombre d`adh�rents'
	from Activite A
	inner join Inscription I
	on A.refActivite = I.refActivite
	group by A.refActivite, intitule, NbMaxParticipant
end
go
-- 9)
go
create proc sp_inscrire_toutes_adherent(@code int)
as
begin
	insert into Inscription
	select @code, refActivite, GETDATE()
	from Activite
end
go
-- 10)
go
create proc sp_supprimer_adherent(@code int)
as
begin
	delete from Inscription
	where code = @code
	
	delete from Adherent
	where code = @code
end
go