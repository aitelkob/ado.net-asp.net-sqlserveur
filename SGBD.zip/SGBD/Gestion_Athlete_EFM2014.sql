create database Gestion_Athlete

use Gestion_Athlete

create table Piscine (
	NumPiscine int primary key,
	NomPiscine varchar(50),
	AdressePiscine varchar(100)
)

create table Entrainement (
	NumEntrainement int primary key,
	DateEntraiment date,
	HeureDebut date,
	HeureFin date,
	NumPiscine int references Piscine(NumPiscine)
)

create table Athlete (
	NumLicence int primary key,
	NomAthlete varchar(30),
	PrenomAthlete varchar(30),
	CategorieAthlete varchar(30)
)

create table Pl_Entrainement (
	NumEntrainement int references Entrainement(NumEntrainement),
	NumLicence int references Athlete(NumLicence),
	DistanceAParcourir int,
	DistanceParcourir int,
	primary key(NumEntrainement, NumLicence)
)


insert into Athlete
values(1, 'FAKHAM', 'Mohammed', 'Categorie 1'),
      (2, 'KARAMI', 'Rida', 'Categorie 1'),
	  (3, 'FALAHI', 'Marouane', 'Categorie 2')

insert into Piscine
values(1, 'Piscine 1', 'Casa'),
      (2, 'Piscine 2', 'Rabat')

insert into Entrainement
values(1, getdate(), getdate(), getdate(), 1)

insert into Pl_Entrainement
values(1, 1, 8, 5)

select DateEntraiment, HeureDebut, HeureFin, NomPiscine, DistanceAParcourir, DistanceParcourir
from Pl_Entrainement PE
inner join Entrainement E
on PE.NumEntrainement = E.NumEntrainement
inner join Piscine P
on E.NumPiscine = P.NumPiscine
where NumLicence = 1
order by DateEntraiment desc

select * 
from Entrainement
where DATEDIFF(month,DateEntraiment, GETDATE()) = 0