create database Tdi

go

use Tdi

go 

create table Stagiare
( 
Matricule int primary key not null,
nom varchar(25),
prenom varchar(25),
Moyenne float,
age int )

insert into  Stagiare values (1,'nom1','prenom1',18,25),
                              (2,'nom2','prenom2',20,25),
							  (3,'nom3','prenom3',18,25),
							  (4,'nom4','prenom4',50,25),
							  (5,'nom5','prenom5',60,25)

delete from Stagiare where Matricule=6

update Stagiare set Matricule= ,nom=  , Moyenne=   ,age=


select * from Stagiare